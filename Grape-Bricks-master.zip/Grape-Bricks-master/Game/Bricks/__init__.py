from Game.Bricks.Brick import *
from Game.Bricks.SpecialBrickLife import *
from Game.Bricks.SpecialBrickSpeed import *
