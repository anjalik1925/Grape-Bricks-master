from Game.Scenes.Scene import *
from Game.Scenes.GameOverScene import *
from Game.Scenes.HighScoreScene import *
from Game.Scenes.MenuScene import *
from Game.Scenes.PlayingScene import *

