<h1 align="center">
  Grape Bricks
</h1>

[About](#about) ---- [Running The Game](#running-the-game) ---- [Future Scope](#future-scope)

## About

Grape Bricks is a simple breakout like game made in python and pygame ...

It works like normal breakout and has some functionalities you'd expect for example powerups..

## Running The Game

To run the game ... All you gotta do is download this repository , go to Game folder and then run Breakout.py...

> Note that you would need python and pygame installed in your system

You can download python from [here](https://www.python.org/downloads/)

To download pygame you would need Pip installed in your System which will be automatically installed if you install python....Then just install pygame using the commad

```bash
pip install pygame
```

More info at https://www.pygame.org/wiki/GettingStarted

## Future Scope

- adding more powerups
- some more animations
- a store or something like that
